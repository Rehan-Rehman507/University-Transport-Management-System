#include "Energy_log.h"
Energy_log::Energy_log(int id, float u)
{
    device_id = id;
    units = u;
}
void Energy_log::display()
{
    cout <<endl<<"Device ID : " << device_id;
    cout <<endl<<"Units : " << units << endl;
}
void Energy_log::save(ofstream& file)
{
    file << device_id << " " << units << endl;
}
int Energy_log::getDeviceID()
{
    return device_id;
}