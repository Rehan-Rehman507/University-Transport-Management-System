#pragma once
#include <iostream>
#include <fstream>
using namespace std;
class Energy_log
{
    int device_id;
    float units;
public:
    Energy_log(int id = 0, float u = 0);
    void display();
    void save(ofstream& file);
    int getDeviceID();
};
