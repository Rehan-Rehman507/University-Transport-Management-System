#include "Room.h"
Room::Room(int id, string n)
{
    room_id = id;
    room_name = n;
}
void Room::display()
{
    cout <<endl<< "Room ID : " << room_id;
    cout <<endl<< "Room Name : " << room_name << endl;
}
void Room::save(ofstream& file)
{
    file << room_id << " " << room_name << endl;
}
string Room::getRoomName()
{
    return room_name;
}