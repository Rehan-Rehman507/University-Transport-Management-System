#pragma once
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
class Room
{
    int room_id;
    string room_name;
public:
    Room(int id = 0, string n = " ");
    void display();
    void save(ofstream& file);
    string getRoomName();
};
