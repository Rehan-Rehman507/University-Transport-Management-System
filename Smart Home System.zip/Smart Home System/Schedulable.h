#pragma once
class Schedulable           // Abstract class because it has
{                          // only pure virtual function
public:
    virtual void schedule_task() = 0;    // pure virtual funvtion
};