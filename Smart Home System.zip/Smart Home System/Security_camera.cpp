#include "Security_camera.h"
Security_camera::Security_camera(int id,string n,string loc,bool s,int r,bool rec):Smart_device(id, n, loc, s)
{
    resolution = r;
    recording = rec;
}
void Security_camera::start_recording()
{
    recording = true;
}
void Security_camera::stop_recording()
{
    recording = false;
}
void Security_camera::display()
{
    cout << endl << "==============================";
    cout << endl << "SECURITY CAMERA";
    cout << endl << "==============================";
    cout << endl << "ID : " << device_id;
    cout << endl << "Name : " << name;
    cout << endl << "Location : " << location;
    cout << endl << "Resolution : " << resolution;
    cout << endl << "Recording : " << (recording ? "YES" : "NO") << endl;
}
void Security_camera::save(ofstream& file)
{
    file << "CAMERA "<< device_id << " "<< name << " "<< location << " "<< status << " "<< resolution << " "<< recording << endl;
}