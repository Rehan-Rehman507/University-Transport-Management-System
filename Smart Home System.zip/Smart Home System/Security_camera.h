#pragma once
#include "Smart_device.h"
class Security_camera : public Smart_device
{
    int resolution;
    bool recording;
public:
    Security_camera(int id = 0,string n = "",string loc = "",bool s = false,int r = 0,bool rec = false);
    void start_recording();
    void stop_recording();
    void display();
    void save(ofstream& file);
};