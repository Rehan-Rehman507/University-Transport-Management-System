#include "Smart_home.h"
#include "User.h"
void menu()
{
    cout << endl << "               ==============================";
    cout << endl << "                          M E N U";
    cout << endl << "               =============================="<<endl;
    cout << endl<<"*******************************";
    cout << endl << "1. Add Device";
    cout << endl << "2. View Devices";
    cout << endl << "3. Search Device";
    cout << endl << "4. Toggle Device";
    cout << endl << "5. Remove Device";
    cout << endl << "6. Add Room";
    cout << endl << "7. View Rooms";
    cout << endl << "8. Add Energy Log";
    cout << endl << "9. View Energy Logs";
    cout << endl << "10. Start Camera Recording";
    cout << endl << "11. Stop Camera Recording";
    cout << endl << "12. Unlock Smart Lock";
    cout << endl << "13. Lock Smart Lock";
    cout << endl << "14. Dashboard";
    cout << endl << "15. Save Devices";
    cout << endl << "16. Save Rooms";
    cout << endl << "17. Save Logs";
    cout << endl << "18. Logout";
    cout << endl << "*******************************" << endl;
    cout << endl << "Enter Choice : ";
}
int main()
{
    Smart_home home;
    User user;
    int option;
    do
    {
        cout << endl << "               ===========================================";
        cout << endl << "                       SMARTNEST AUTOMATION SYSTEM";
        cout << endl << "               ==========================================="<<endl;
        cout << endl << "******************";
        cout << endl << "   1. Signup";
        cout << endl << "   2. Login";
        cout << endl << "   3. Exit";
        cout << endl << "******************"<<endl;
        cout << endl << "Enter your choice: ";
        cin >> option;
        if (option == 1)
        {
            user.signup();      // Sign up Page
        }
        else if (option == 2)
        {
            if (user.login())   // Login page
            {
                int choice;
                do
                {
                    menu();
                    cin >> choice;
                    switch (choice)
                    {
                    case 1:
                        home.add_device();
                        break;
                    case 2:
                        home.view_devices();
                        break;
                    case 3:
                        home.search_device();
                        break;
                    case 4:
                        home.toggle_device();
                        break;
                    case 5:
                        home.remove_device();
                        break;
                    case 6:
                        home.add_room();
                        break;
                    case 7:
                        home.viewRoomDevices();
                        break;
                    case 8:
                        home.add_energy_log();
                        break;
                    case 9:
                        home.view_energy_logs();
                        break;
                    case 10:
                        home.startCameraRecording();
                        break;
                    case 11:
                        home.stopCameraRecording();                        
                        break;
                    case 12:
                        home.unlockSmartLock();
                        break;
                    case 13:
                        home.lockSmartLock(); 
                        break;
                    case 14:
                        home.dashboard();
                        break;
                    case 15:
                        home.save_devices();
                        break;
                    case 16:
                        home.save_rooms();
                        break;
                    case 17:
                        home.save_logs();
                        break;
                    case 18:
                        cout << endl << "Logout Successful" << endl;
                        break;
                    }
                } while (choice != 18);
            }
            else
            {
                cout << endl << "Invalid Login"<<endl;
            }
        }
    } while (option != 3);
    cout <<endl<< " *** SMARTNEST AUTOMATION SYSTEM *** Signing off..." << endl;
    return 0;
}