#include "Smart_appliance.h"
Smart_appliance::Smart_appliance(int id,string n,string loc,bool s,int p): Smart_device(id, n, loc, s)
{
    power = p;
}