#pragma once
#include "Smart_device.h"
class Smart_appliance : public Smart_device
{
protected:
    int power;
public:
    Smart_appliance(int id = 0,string n = "",string loc = "",bool s = false,int p = 0);
};