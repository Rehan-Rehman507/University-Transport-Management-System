#include "Smart_device.h"
Smart_device::Smart_device(int id, string n, string loc, bool s)
{
    device_id = id;
    name = n;
    location = loc;
    status = s;
}
Smart_device::~Smart_device()
{
}
void Smart_device::toggle()
{
    status = !status;
}
int Smart_device::get_id()
{
    return device_id;
}
bool Smart_device::get_status()
{
    return status;
}
string Smart_device::getLocation()
{
    return location;
}