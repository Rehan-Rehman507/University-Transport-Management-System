#pragma once
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
class Smart_device
{
protected:
    int device_id;
    string name;
    string location;
    bool status;
public:
    Smart_device(int id = 0, string n = "", string loc = "", bool s = false);
    virtual ~Smart_device();        // virtual destructor
    virtual void display() = 0;
    virtual void toggle();
    virtual void save(ofstream& file) = 0;
    int get_id();
    bool get_status();
    string getLocation();
};