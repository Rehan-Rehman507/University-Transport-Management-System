#include "Smart_home.h"
Smart_home::Smart_home()
{
    devices = new Smart_device * [100];
    logs = new Energy_log[100];
    rooms = new Room[100];
    device_count = 0;
    log_count = 0;
    room_count = 0;
    load_devices();
    load_rooms();
    load_logs();
}
Smart_home::~Smart_home()
{
    for (int i = 0; i < device_count; i++)
    {
        delete devices[i];
    }
    delete[] devices;
    delete[] logs;
    delete[] rooms;
}
void Smart_home::add_device()
{
    int choice;
    cout << endl << "***********************";
    cout << endl << "1. Smart Light";
    cout << endl << "2. Thermostat";
    cout << endl << "3. Security Camera";
    cout << endl << "4. Smart Lock";
    cout << endl << "5. Smart Speaker";
    cout << endl << "***********************" << endl;
    cout << endl << "Enter Choice : ";
    cin >> choice;
    int id;
    string name;
    string location;
    cout << endl << "Enter ID : ";
    cin >> id;
    cout << endl << "Enter Name : ";
    cin >> name;
    cout << endl << "Enter Location : ";
    cin >> location;
    if (choice == 1)
    {
        int brightness;
        string color;
        cout << endl << "Enter brightness: ";
        cin >> brightness;
        cout << endl << "Enter color: ";
        cin >> color;
        devices[device_count++] =new Smart_light(id, name, location, false, brightness, color);
    }
    else if (choice == 2)
    {
        float temp;
        string mode;
        cout << endl << "Enter temperature: ";
        cin >> temp;
        cout << endl << "Enter mode: ";
        cin >> mode;
        devices[device_count++] =new Thermostat(id, name, location, false, temp, mode);
    }
    else if (choice == 3)
    {
        int resolution;
        cout << endl << "Enter Resolution : ";
        cin >> resolution;
        devices[device_count++] =
            new Security_camera(id,name,location,false,resolution,false);
    }
    else if (choice == 4)
    {
        int power;
        string code;
        cout << endl << "Enter Power Rating : ";
        cin >> power;
        cout << endl << "Enter Access Code : ";
        cin >> code;
        devices[device_count++] =new Smart_lock(id,name,location,false,power,code,true);
    }
    else if (choice == 5)
    {
        int power;
        int volume;
        cout << endl << "Enter Power Rating : ";
        cin >> power;
        cout << endl << "Enter Volume : ";
        cin >> volume;
        devices[device_count++] =new Smart_speaker(id,name,location,false,power,volume);
    }
    else
    {
        cout <<endl<< "Invalid Choice"<<endl;
        return;
    }
    cout << endl << "Device Added Successfully"<<endl;
}
void Smart_home::view_devices()
{
    for (int i = 0; i < device_count; i++)
    {
        devices[i]->display();
    }
}
void Smart_home::search_device()
{
    int id;
    cout << "Enter ID: " << endl;
    cin >> id;
    for (int i = 0; i < device_count; i++)
    {
        if (devices[i]->get_id() == id)
        {
            devices[i]->display();
            return;
        }
    }
    cout << endl << "Not Found"<<endl;
}
void Smart_home::toggle_device()
{
    int id;
    cout << "Enter ID: " << endl;
    cin >> id;
    for (int i = 0; i < device_count; i++)
    {
        if (devices[i]->get_id() == id)
        {
            devices[i]->toggle();
            cout << "Device toggled successfully" << endl;
            return;
        }
    }
    cout << "Device not found" << endl;
}
void Smart_home::remove_device()
{
    int id;
    cout << "Enter ID: " << endl;
    cin >> id;
    for (int i = 0; i < device_count; i++)
    {
        if (devices[i]->get_id() == id)
        {
            delete devices[i];
            for (int j = i; j < device_count - 1; j++)
            {
                devices[j] = devices[j + 1];
            }
            device_count--;
            cout << endl << "Removed"<<endl;
            return;
        }
    }
    cout << "Device not found" << endl;
}
void Smart_home::add_room()
{
    int id;
    string name;
    cout << "Enter ID: ";
    cin >> id;
    cout << endl << "Enter name: ";
    cin>> name;
    rooms[room_count++] = Room(id, name);
    cout << "Room added sucessfully" << endl;
}
void Smart_home::viewRoomDevices()
{
    string roomName;

    cout << "\nEnter Room Name : ";
    cin >> roomName;

    bool roomFound = false;

    for (int i = 0; i < room_count; i++)
    {
        if (rooms[i].getRoomName() == roomName)
        {
            roomFound = true;
            break;
        }
    }

    if (!roomFound)
    {
        cout << "\nRoom Not Found\n";
        return;
    }

    cout << "\nDevices In " << roomName << ":\n";

    bool deviceFound = false;

    for (int i = 0; i < device_count; i++)
    {
        if (devices[i]->getLocation() == roomName)
        {
            devices[i]->display();
            deviceFound = true;
        }
    }

    if (!deviceFound)
    {
        cout << "\nNo Devices In This Room\n";
    }
}
//void Smart_home::add_energy_log()
//{
//    int id;
//    float units;
//    cout << "Enter ID: ";
//    cin >> id;
//    cout << endl << "Enter units: ";
//    cin>> units;
//    logs[log_count++] = Energy_log(id, units);
//}
void Smart_home::add_energy_log()
{
    int id;
    float units;

    cout << "\nEnter Device ID : ";
    cin >> id;

    bool found = false;

    for (int i = 0; i < device_count; i++)
    {
        if (devices[i]->get_id() == id)
        {
            found = true;

            cout << "\nDevice Found\n";

            cout << "Enter Monthly Units Used : ";
            cin >> units;

            logs[log_count++] = Energy_log(id, units);

            cout << "\nEnergy Log Added Successfully\n";

            break;
        }
    }

    if (!found)
    {
        cout << "\nDevice Not Found\n";
    }
}
//void Smart_home::view_energy_logs()
//{
//    for (int i = 0; i < log_count; i++)
//    {
//        logs[i].display();
//    }
//}
void Smart_home::view_energy_logs()
{
    if (log_count == 0)
    {
        cout << "\nNo Energy Logs Found\n";
        return;
    }

    for (int i = 0; i < log_count; i++)
    {
        logs[i].display();
    }
}
void Smart_home::startCameraRecording()
{
    int id;

    cout << "\nEnter Camera ID : ";
    cin >> id;

    for (int i = 0; i < device_count; i++)
    {
        if (devices[i]->get_id() == id)
        {
            Security_camera* camera =
                dynamic_cast<Security_camera*>(devices[i]);

            if (camera)
            {
                camera->start_recording();

                cout << "\nRecording Started\n";
                return;
            }
        }
    }

    cout << "\nCamera Not Found\n";
}
void Smart_home::stopCameraRecording()
{
    int id;

    cout << "\nEnter Camera ID : ";
    cin >> id;

    for (int i = 0; i < device_count; i++)
    {
        if (devices[i]->get_id() == id)
        {
            Security_camera* camera =
                dynamic_cast<Security_camera*>(devices[i]);

            if (camera)
            {
                camera->stop_recording();

                cout << "\nRecording Stopped\n";
                return;
            }
        }
    }

    cout << "\nCamera Not Found\n";
}
void Smart_home::unlockSmartLock()
{
    int id;
    string code;

    cout << "\nEnter Lock ID : ";
    cin >> id;

    cout << "Enter Access Code : ";
    cin >> code;

    for (int i = 0; i < device_count; i++)
    {
        if (devices[i]->get_id() == id)
        {
            Smart_lock* lock =
                dynamic_cast<Smart_lock*>(devices[i]);

            if (lock)
            {
                lock->unlock(code);
                return;
            }
        }
    }

    cout << "\nSmart Lock Not Found\n";
}
void Smart_home::lockSmartLock()
{
    int id;

    cout << "\nEnter Lock ID : ";
    cin >> id;

    for (int i = 0; i < device_count; i++)
    {
        if (devices[i]->get_id() == id)
        {
            Smart_lock* lock =
                dynamic_cast<Smart_lock*>(devices[i]);

            if (lock)
            {
                lock->lock();
                return;
            }
        }
    }

    cout << "\nSmart Lock Not Found\n";
}
void Smart_home::dashboard()
{
    cout << endl << "Total Devices : " << device_count;
    cout << endl << "Rooms : " << room_count;
    cout << endl << "Logs : " << log_count << endl;
}
void Smart_home::save_devices()
{
    ofstream file("devices.txt");
    for (int i = 0; i < device_count; i++)
    {
        devices[i]->save(file);
    }
    file.close();
    cout << endl << "--------------------------------------" << endl;
    cout << "Devices saved successfully to the files";
    cout << endl << "--------------------------------------" << endl;
}
void Smart_home::save_rooms()
{
    ofstream file("rooms.txt");
    for (int i = 0; i < room_count; i++)
    {
        rooms[i].save(file);
    }
    file.close();
    cout << endl << "--------------------------------------" << endl;
    cout << "rooms saved successfully to the files";
    cout << endl << "--------------------------------------" << endl;
}
void Smart_home::save_logs()
{
    ofstream file("energylogs.txt");
    for (int i = 0; i < log_count; i++)
    {
        logs[i].save(file);
    }
    file.close();
    cout << endl << "--------------------------------------" << endl;
    cout << "logs saved successfully to the files";
    cout << endl << "--------------------------------------" << endl;
}
void Smart_home::load_rooms()
{
    ifstream file("rooms.txt");
    int id;
    string name;
    while (file >> id >> name)
    {
        rooms[room_count++] = Room(id, name);
    }
    file.close();
}
void Smart_home::load_logs()
{
    ifstream file("energylogs.txt");
    int id;
    float units;
    while (file >> id >> units)
    {
        logs[log_count++] = Energy_log(id, units);
    }
    file.close();
}
void Smart_home::load_devices()
{
    ifstream file("devices.txt");
    string type;
    while (file >> type)
    {
        if (type == "LIGHT"||type=="light")
        {
            int id;
            string name;
            string location;
            bool status;
            int brightness;
            string color;
            file >> id >> name >> location >> status >> brightness >> color;
            devices[device_count++] =new Smart_light(id,name,location,status,brightness,color);
        }
        else if (type == "THERMOSTAT" || type == "thermostat")
        {
            int id;
            string name;
            string location;
            bool status;
            float temperature;
            string mode;
            file >> id>> name>> location>> status>> temperature>> mode;
            devices[device_count++] =new Thermostat(id,name,location,status,temperature,mode);
        }
        else if (type == "CAMERA" || type == "camera")
        {
            int id;
            string name;
            string location;
            bool status;
            int resolution;
            bool recording;
            file >> id>> name>> location>> status>> resolution>> recording;
            devices[device_count++] =new Security_camera(id,name,location,status,resolution,recording);
        }
        else if (type == "LOCK"||type=="lock")
        {
            int id;
            string name;
            string location;
            int power;
            string code;
            bool locked;
            file >> id>> name>> location>> power>> code>> locked;
            devices[device_count++] =new Smart_lock(id,name,location,false,power,code,locked);
        }
        else if (type == "SPEAKER"||type=="speaker")
        {
            int id;
            string name;
            string location;
            int power;
            int volume;
            file >> id>> name>> location>> power>> volume;
            devices[device_count++] =new Smart_speaker(id,name,location,false,power,volume);
        }
    }
    file.close();
}