#pragma once
#include "Smart_light.h"
#include "Thermostat.h"
#include "Security_camera.h"
#include "Smart_lock.h"
#include "Smart_speaker.h"
#include "Energy_log.h"
#include "Room.h"
class Smart_home
{
    Smart_device** devices;
    Energy_log* logs;
    Room* rooms;
    int device_count;
    int log_count;
    int room_count;
public:
    Smart_home();
    ~Smart_home();
    void add_device();
    void view_devices();
    void search_device();
    void toggle_device();
    void remove_device();
    void add_room();
    void viewRoomDevices();
    void add_energy_log();
    void view_energy_logs();
    void startCameraRecording();
    void stopCameraRecording();
    void unlockSmartLock();
    void lockSmartLock();
    void dashboard();
    void save_devices();
    void save_rooms();
    void save_logs();
    void load_devices();
    void load_rooms();
    void load_logs();
};