#include "Smart_light.h"
Smart_light::Smart_light(int id,string n,string loc,bool s,int b,string c): Smart_device(id, n, loc, s)
{
    brightness = b;
    color = c;
}
void Smart_light::schedule_task()
{
    cout <<endl<< "Light Schedule Added"<<endl;
}
void Smart_light::display()
{
    cout << endl << "==============================";
    cout << endl << "SMART LIGHT";
    cout << endl << "==============================";
    cout << endl << "ID : " << device_id;
    cout << endl << "Name : " << name;
    cout << endl << "Location : " << location;
    cout << endl << "Status : " << (status ? "ON" : "OFF");
    cout << endl << "Brightness : " << brightness;
    cout << endl << "Color : " << color << endl;
}
void Smart_light::save(ofstream& file)
{
    file << "LIGHT "<< device_id << " "<< name << " "<< location << " "<< status << " "<< brightness << " "<< color << endl;
}