#pragma once
#include "Smart_device.h"
#include "Schedulable.h"
class Smart_light : public Smart_device, public Schedulable
{
    int brightness;
    string color;
public:
    Smart_light(int id = 0,string n = "",string loc = "",bool s = false,int b = 0,string c = "");
    void schedule_task();
    void display();
    void save(ofstream& file);
};