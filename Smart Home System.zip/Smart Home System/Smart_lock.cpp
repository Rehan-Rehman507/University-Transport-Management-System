#include "Smart_lock.h"
Smart_lock::Smart_lock(int id,string n,string loc,bool s,int p,string c,bool l): Smart_appliance(id, n, loc, s, p)
{
    code = c;
    locked = l;
}
void Smart_lock::lock()
{
    locked = true;

    cout << "\nDoor Locked Successfully\n";
}

void Smart_lock::unlock(string c)
{
    if (c == code)
    {
        locked = false;
        cout << endl << "Unlocked Successfully"<<endl;
    }
    else
    {
        cout << endl << "Wrong Code"<<endl;
    }
}
void Smart_lock::display()
{
    cout << endl << "==============================";
    cout << endl << "SMART LOCK";
    cout << endl << "==============================";
    cout << endl << "ID : " << device_id;
    cout << endl << "Name : " << name;
    cout << endl << "Location : " << location;
    cout << endl << "Power : " << power;
    cout << endl << "Locked : " << (locked ? "YES" : "NO") << endl;
}
void Smart_lock::save(ofstream& file)
{
    file << "LOCK "<< device_id << " "<< name << " "<< location << " "<< power << " "<< code << " "<< locked << endl;
}