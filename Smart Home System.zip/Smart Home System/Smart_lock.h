#pragma once
#include "Smart_appliance.h"
class Smart_lock : public Smart_appliance
{
    string code;
    bool locked;
public:
    Smart_lock(int id = 0,string n = "",string loc = "",bool s = false,int p = 0,string c = "",bool l = true);
    void lock();
    void unlock(string c);
    void display();
    void save(ofstream& file);
};