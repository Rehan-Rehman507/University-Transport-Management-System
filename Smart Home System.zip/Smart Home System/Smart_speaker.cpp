#include "Smart_speaker.h"
Smart_speaker::Smart_speaker(int id,string n,string loc,bool s,int p,int v): Smart_appliance(id, n, loc, s, p)
{
    volume = v;
}
void Smart_speaker::voice_command()
{
    cout << endl << "Voice Command Executed"<<endl;
}
void Smart_speaker::display()
{
    cout << endl << "==============================";
    cout << endl << "SMART SPEAKER";
    cout << endl << "==============================";
    cout << endl << "ID : " << device_id;
    cout << endl << "Name : " << name;
    cout << endl << "Volume : " << volume << endl;
}
void Smart_speaker::save(ofstream& file)
{
    file << "SPEAKER "<< device_id << " "<< name << " "<< location << " "<< power << " "<< volume << endl;
}