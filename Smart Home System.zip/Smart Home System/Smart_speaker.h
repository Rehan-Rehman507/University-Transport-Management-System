#pragma once
#include "Smart_appliance.h"
class Smart_speaker : public Smart_appliance
{
    int volume;
public:
    Smart_speaker(int id = 0,string n = "",string loc = "",bool s = false,int p = 0,int v = 0);
    void voice_command();
    void display();
    void save(ofstream& file);
};