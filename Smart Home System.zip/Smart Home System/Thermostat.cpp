#include "Thermostat.h"
Thermostat::Thermostat(int id,string n,string loc,bool s,float t,string m): Smart_device(id, n, loc, s)
{
    temperature = t;
    mode = m;
}
void Thermostat::schedule_task()
{
    cout << endl << "Thermostat Schedule Added" << endl;
}
void Thermostat::display()
{
    cout << endl << "==============================";
    cout << endl << "THERMOSTAT";
    cout << endl << "==============================";
    cout << endl << "ID : " << device_id;
    cout << endl << "Name : " << name;
    cout << endl << "Location : " << location;
    cout << endl << "Status : " << (status ? "ON" : "OFF");
    cout << endl << "Temperature : " << temperature;
    cout << endl << "Mode : " << mode << endl;
}
void Thermostat::save(ofstream& file)
{
    file << "THERMOSTAT "<< device_id << " "<< name << " "<< location << " "<< status << " "<< temperature << " "<< mode << endl;
}