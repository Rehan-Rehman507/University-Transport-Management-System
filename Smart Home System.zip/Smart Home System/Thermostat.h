#pragma once
#include "Smart_device.h"
#include "Schedulable.h"
class Thermostat : public Smart_device, public Schedulable
{
    float temperature;
    string mode;
public:
    Thermostat(int id = 0,string n = "",string loc = "",bool s = false,float t = 0,string m = "");
    void schedule_task();
    void display();
    void save(ofstream& file);
};