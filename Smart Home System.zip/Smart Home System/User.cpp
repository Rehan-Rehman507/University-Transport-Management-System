#include "User.h"
void User::signup()
{
    cout << endl << "======================"
        << endl << "      Sign-Up Page    "
        << endl << "======================" << endl;
    cout <<endl<< "Account Creation For *** SMARTNEST AUTOMATION SYSTEM ***..." << endl;
    cout << endl << "Enter Username : ";
    cin >> username;
    cout << endl << "Enter Password : ";
    cin >> password;
    ofstream file("users.txt", ios::app);
    file << username << " " << password << endl;
    file.close();
    cout << endl << "Signup Successful"<<endl;
}
bool User::login()
{
    string u;
    string p;
    cout << endl << "======================"
        << endl << "      Login Page       "
        << endl << "======================" << endl;
    cout <<endl<< "Signing In For *** SMARTNEST AUTOMATION SYSTEM ***..." << endl;
    cout << endl << "Enter Username : ";
    cin >> u;
    cout << endl << "Enter Password : ";
    cin >> p;
    ifstream file("users.txt");
    while (file >> username >> password)
    {
        if (u == username && p == password)
        {
            file.close();
            cout <<endl<< "Successfully logged in." << endl;
            cout <<endl<< "---- Welcome " << username <<" ----" << endl;
            return true;
        }
    }
    file.close();
    return false;
}