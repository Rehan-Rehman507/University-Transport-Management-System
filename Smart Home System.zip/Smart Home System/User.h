#pragma once
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
class User
{
    string username;
    string password;
public:
    void signup();
    bool login();
};